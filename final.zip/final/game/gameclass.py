class Person:
  def __init__(self, level, health, attack):
    self.level = level
    self.maxhealth = health
    self.currenthealth = health
    self.attack = attack


class computer:
  def __init__(self, level, health, attack):
    self.level = level
    self.maxhealth = health
    self.currenthealth = health
    self.attack = attack
