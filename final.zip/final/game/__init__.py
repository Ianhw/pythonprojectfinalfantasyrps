#package

from tkinter import *
from game.gameclass import Person
from game.gameclass import computer
import datetime
import random
